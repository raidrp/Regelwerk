# Offizielle AGB des Servers RaidRP vom 18.02.19

# Einleitung
`Diese AGB gilt zu 100% und kann in keinem Fall umgangen werden.`
`Sie beinhaltet eure Rechte und Vorschriften zu der Benutzung des FiveM Servers RaidRP 
und hat höchste Priorität im Falle eines Missverständnisses o.ä.`
     
# Haftbarkeit
- Wir sind nicht haftbar im Falle dass Sie oder eine weitere Person auf diesem Server unter 18 Jahre alt sind.
bereits bei dem Kauf von GTA stimmen Sie zu, GTA mit 18 Jahren erworben zu haben.
Sollte dies nicht der Fall sein, sind Sie für alle Verstöße oder ihre Eltern aufzukommen.

- Im Falle eines permanenten oder temporären Bannes kommt Real Roleplay nicht für die "gestohlene" Zeit auf,
die benötigt wurde um bestimmte ingame- Items oder Gegenstände zu erarbeiten.

- Im Falle das ihr GTA nicht mehr funktioniert o.ä. kommt RaidRP *nicht* hierfür auf.
Wir verwenden nur getestete resourcen und fügen niemals resourcen ein die Schädlich sind oder 
Informationen über ihr Konto sammeln. Probleme mit FiveM können im FiveM Support erklärt werden,
dafür ist RaidRP nicht zuständig.

# Strafen
- Sollte ein allgemeines Vergehen, gegen die Allgemeinen Regeln vorliegen, hält sich das Admin Team vor eine gerechte
und angemessene Strafe für dieses vergehen zu vergeben. Diese Entscheidung kann im Teamspeak angefochten werden.
Sollte dies der Fall sein, wird der Server Owner sich dieses Problem widmen und für beide Seiten eine angemessene Lösung finden. Sollte die Strafe vom Server Owner ausgestellt worden sein, kann dieses nur angefochten werden, wenn das Admin Team diese Entscheidung als nicht gerecht einstuft.


- Jeder User hat sich freundlich zu verhalten, schwere Beleidungen werden mit einem permanenten Bann bestraft.
Dies kann *nicht* angefochten werden! Jeder user hat sich an diese Regel zu halten und muss diese akzeptieren.

- Werben von anderen Servern oder das werben von diesem auf anderen Servern wird im Ermessen der Admins mit einem
permanenten Bann bestraft. Dies gilt nicht für das werben an *einzelne* **bekannte** Personen, diese haben jedoch das
Recht diese Werbung abzulehnen, woran sich der werbende halten **muss**.

- das Benutzen von Hacks, Glitches o.ä wird unanfechtbar mit einem permanenten Bann bestraft.

- Das trollen kann im Ermessen der Admins mit einem Bann bestraft werden. Siehe dazu Abschnitt eins der Strafen.

- Alle weiteren Strafen liegen im Ermessen der Admins und fallen unter dem ersten Abschnitt der Strafen.

# Autoren

- RaidRP / Andy


©Copyright-@Raid-RP_2019
